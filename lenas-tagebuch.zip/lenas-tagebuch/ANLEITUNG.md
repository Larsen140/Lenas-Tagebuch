# Lenas Tagebuch – Anleitung

Einmal einrichten dauert ca. 10 Minuten. Danach läuft alles von selbst.

---

## Schritt 1: Die App online stellen (Repo 1 – öffentlich)

1. Auf **github.com** einloggen.
2. Oben rechts auf **+** → **New repository**.
3. Name: `lenas-tagebuch` · **Public** auswählen · **Create repository**.
4. Auf **uploading an existing file** klicken.
5. Alle Dateien aus diesem Ordner hochziehen:
   `index.html`, `manifest.json`, `sw.js` und den Ordner `icons` (komplett).
   *(Diese Anleitung musst du nicht hochladen.)*
6. Unten auf **Commit changes**.
7. Im Repo: **Settings** → links **Pages** → bei *Branch* `main` und `/ (root)` wählen → **Save**.
8. Nach 1–2 Minuten steht oben die Adresse, z. B.
   `https://DEINNAME.github.io/lenas-tagebuch/`

---

## Schritt 2: Speicher für Lenas Daten (Repo 2 – privat)

1. Wieder **+** → **New repository**.
2. Name: `lenas-tagebuch-daten` · **Private** auswählen.
3. Haken bei **Add a README file** setzen.
4. **Create repository**. Fertig – da musst du nichts weiter reinlegen, die App macht das selbst.

---

## Schritt 3: Schlüssel (Token) erstellen

Der Token erlaubt der App, *nur* in das private Daten-Repo zu schreiben.

1. Oben rechts auf dein Profilbild → **Settings**.
2. Ganz unten links **Developer settings** → **Personal access tokens** → **Fine-grained tokens** → **Generate new token**.
3. Name: `Lenas Tagebuch`
4. **Expiration:** die längste Laufzeit wählen, die angeboten wird.
5. **Repository access:** *Only select repositories* → `lenas-tagebuch-daten` auswählen.
6. **Permissions** → **Repository permissions** → **Contents** auf **Read and write** stellen.
7. **Generate token** → den Token (beginnt mit `github_pat_…`) kopieren.
   ⚠️ Er wird nur einmal angezeigt – kurz irgendwo sicher notieren und **niemandem schicken**.

---

## Schritt 4: Auf iPhone und iPad installieren

Auf **jedem** Gerät:

1. Die Adresse aus Schritt 1 in **Safari** öffnen.
2. Unten auf **Teilen** (Quadrat mit Pfeil) → **Zum Home-Bildschirm** → **Hinzufügen**.
3. Die App über das neue Icon öffnen.
   *(Im normalen Safari-Fenster lässt sich die App absichtlich nicht benutzen – sie zeigt dort nur diese Anleitung. Am Computer geht sie normal, zum Testen.)*
4. Oben rechts auf das **Zahnrad** → *Synchronisation*:
   - **GitHub-Benutzername:** dein Name auf GitHub
   - **Daten-Repository:** `lenas-tagebuch-daten`
   - **Token:** den kopierten Token einfügen
5. **Verbinden & synchronisieren** tippen → es sollte „✓ Verbunden" erscheinen.

Ab jetzt sind iPhone und iPad automatisch synchron.

---

## Gut zu wissen

- **Wann wird synchronisiert?** Beim Öffnen der App, kurz nach jeder Änderung und alle 90 Sekunden, solange die App offen ist. Der Pfeil-Knopf oben synchronisiert sofort.
- **Ohne Internet?** Die App funktioniert trotzdem. Alles wird nachgeholt, sobald wieder Internet da ist.
- **Roter Punkt am Sync-Knopf?** Dann gab es ein Problem – in den Einstellungen steht, was los ist. Meistens ist der Token abgelaufen: einfach in Schritt 3 einen neuen erstellen und auf beiden Geräten eintragen.
- **App ändern/aktualisieren?** Neue `index.html` in Repo 1 hochladen (alte ersetzen). Die Geräte holen sich die neue Version beim nächsten Öffnen. Lenas Daten bleiben dabei erhalten.
- **Backup:** In den Einstellungen unter *Daten* kann man jederzeit eine Sicherungsdatei herunterladen.
